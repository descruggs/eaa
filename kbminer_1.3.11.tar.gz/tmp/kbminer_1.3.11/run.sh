CUDA_DEVICE_ORDER=PCI_BUS_ID LD_LIBRARY_PATH=./ ./kbminer --pool vds.666pool.cn:9338 --user VcntxgPNMR4uBvkSuDptJVTcCJBrJSyaWJ7.test --algorithm vds --checkdifficulty $* 
